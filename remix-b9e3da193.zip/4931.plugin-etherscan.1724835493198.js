"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([[4931],{

/***/ 24931:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("import { compile } from './utils'\n\nconst main = async () => {\n  const circuit = await compile()\n}\n\nmain()\n");

/***/ })

}]);
//# sourceMappingURL=4931.plugin-etherscan.1724835493198.js.map